#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import rospy
from std_msgs.msg import Float64, Header
from geometry_msgs.msg import Point
from tricat241_pkg.msg import ObstacleList, Sensor_total as SensorTotalMsg

class SensorTotalNode:
    def __init__(self):
        # Initialize variables to store received data
        #self.obstacles = None
        self.heading = None
        self.enu_position_x = None
        self.enu_position_y = None

        # Setup subscribers
        #rospy.Subscriber("/obstacles", ObstacleList, self.obstacles_callback, queue_size=10)
        rospy.Subscriber("/heading", Float64, self.heading_callback, queue_size=10)
        rospy.Subscriber("/enu_position", Point, self.enu_position_callback, queue_size=10)

        # Setup publisher
        self.sensor_total_pub = rospy.Publisher("/Sensor_total", SensorTotalMsg, queue_size=10)

        # Set a timer to periodically publish the message
        self.timer = rospy.Timer(rospy.Duration(0.1), self.publish_sensor_total)

    #def obstacles_callback(self, msg):
        #rospy.loginfo("obstacles_callback called")
        #self.obstacles = msg.obstacle_list
        #rospy.loginfo(f"Received obstacles: {self.obstacles}")

    def heading_callback(self, msg):
        rospy.loginfo("heading_callback called")
        self.heading = msg.data
        rospy.loginfo(f"Received heading: {self.heading}")

    def enu_position_callback(self, msg):
        rospy.loginfo("enu_position_callback called")
        self.enu_position_x = msg.x
        self.enu_position_y = msg.y
        rospy.loginfo(f"Received ENU position: x={self.enu_position_x}, y={self.enu_position_y}")

    def publish_sensor_total(self, event):
        # Ensure all required data is available
        #if self.obstacles is not None and self.heading is not None and self.enu_position_x is not None and self.enu_position_y is not None:
        if self.heading is not None and self.enu_position_x is not None and self.enu_position_y is not None:
            sensor_total_msg = SensorTotalMsg()

            # Fill the header
            sensor_total_msg.header = Header()
            sensor_total_msg.header.stamp = rospy.Time.now()

            # Fill the message with the received data
            sensor_total_msg.heading = Float64(self.heading)
            sensor_total_msg.enu_position = Point(self.enu_position_x, self.enu_position_y, 0)
            #sensor_total_msg.obstacles = self.obstacles

            self.sensor_total_pub.publish(sensor_total_msg)
            rospy.loginfo("Sensor_total message published")
        else:
            rospy.loginfo("Data not complete for publishing Sensor_total message")

def main():
    rospy.init_node('sensor_total_node')
    node = SensorTotalNode()
    rospy.spin()

if __name__ == "__main__":
    main()
