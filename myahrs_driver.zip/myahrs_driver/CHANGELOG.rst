^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package myahrs_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2018-08-28)
-----------
* fixed: make "parent_frame_id\_" as true parent frame_id in /tf topic and "parent_frame_id\_" as child(for now, "base_link" is parent of "imu_link" as default).
* Contributors: Akio Shigekane, Pyo

0.1.1 (2015-02-21)
------------------
* first public release for indigo
* Contributors: Pyo
