#!/usr/bin/env python
# -*- coding:utf-8 -*-

import rospy
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Vector3
from tf.transformations import euler_from_quaternion
import math

class RPYPublisher:
    def __init__(self):
        rospy.init_node('rpy_publisher', anonymous=True)
        self.rpy_pub = rospy.Publisher('rpy', Vector3, queue_size=10)
        rospy.Subscriber('/imu/data', Imu, self.imu_callback)
        self.rate = rospy.Rate(1) # 1 Hz

    def imu_callback(self, msg):
        orientation = msg.orientation
        quaternion = (orientation.x, orientation.y, orientation.z, orientation.w)
        roll, pitch, yaw = euler_from_quaternion(quaternion)

        # Convert radians to degrees
        roll_deg = math.degrees(roll)
        pitch_deg = math.degrees(pitch)
        yaw_deg = math.degrees(yaw)

        # Publish roll, pitch, yaw in degrees
        rpy_msg = Vector3()
        rpy_msg.x = roll_deg
        rpy_msg.y = pitch_deg
        rpy_msg.z = yaw_deg

        self.rpy_pub.publish(rpy_msg)

    def run(self):
        while not rospy.is_shutdown():
            self.rate.sleep()

if __name__ == '__main__':
    try:
        rpy_publisher = RPYPublisher()
        rpy_publisher.run()
    except rospy.ROSInterruptException:
        pass