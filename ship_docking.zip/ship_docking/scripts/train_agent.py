import gym
from stable_baselines3 import PPO
from ship_docking_env import ShipDockingEnv

if __name__ == "__main__":
    env = ShipDockingEnv()
    model = PPO("MlpPolicy", env, verbose=1)
    model.learn(total_timesteps=10000)
    model.save("ppo_ship_docking")
