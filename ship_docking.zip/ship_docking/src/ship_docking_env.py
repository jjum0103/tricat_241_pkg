import gym
from gym import spaces
import rospy
import numpy as np
from std_msgs.msg import Float32MultiArray

class ShipDockingEnv(gym.Env):
    def __init__(self):
        super(ShipDockingEnv, self).__init__()
        rospy.init_node('ship_docking_env', anonymous=True)

        # 행동 공간: 좌회전, 우회전, 직진
        self.action_space = spaces.Discrete(3)
        # 관측 공간: 위치(x, y), 속도, 방향
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(4,), dtype=np.float32)

        self.state = None
        self.reward = 0
        self.done = False

        # ROS 퍼블리셔와 서브스크라이버 설정
        self.pub = rospy.Publisher('/ship/cmd', Float32MultiArray, queue_size=10)
        rospy.Subscriber("/ship/state", Float32MultiArray, self._state_callback)

    def _state_callback(self, data):
        self.state = np.array(data.data)

    def step(self, action):
        # 행동 수행
        cmd = Float32MultiArray()
        cmd.data = [action]  # 예시로 단순화
        self.pub.publish(cmd)

        # 상태 업데이트 대기
        rospy.sleep(0.1)

        self.reward = self._compute_reward()
        self.done = self._check_done()
        return self.state, self.reward, self.done, {}

    def reset(self):
        # 환경 초기화
        self.state = self._get_initial_state()
        return self.state

    def _compute_reward(self):
        # 보상 계산
        # 예시: 목표 지점까지의 거리
        reward = -np.linalg.norm(self.state[:2])
        return reward

    def _check_done(self):
        # 종료 조건 확인
        # 예시: 목표 지점 도달 여부
        done = np.linalg.norm(self.state[:2]) < 0.1
        return done

    def _get_initial_state(self):
        # 초기 상태 반환
        initial_state = np.array([0.0, 0.0, 0.0, 0.0])
        return initial_state
